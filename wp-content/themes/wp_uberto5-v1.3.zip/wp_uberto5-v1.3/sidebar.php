<div class="col-md-3 col-sm-4">
	<div class="sidebar">
		<?php dynamic_sidebar('blog-sidebar'); ?>
	</div>
</div>