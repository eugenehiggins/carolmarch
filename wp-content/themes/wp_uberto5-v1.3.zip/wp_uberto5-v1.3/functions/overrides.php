<?php 
//
// Use this file to override theme-specific functions.
// Bottom of functions.php is too late for functions override.
// Make sure to wrap the functions in function_exists() checks so that
// child themes get a chance to override as well.
//



?>