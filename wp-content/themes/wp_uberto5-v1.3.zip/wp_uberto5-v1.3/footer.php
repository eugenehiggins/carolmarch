	<footer id="footer">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<span><?php echo ci_footer(); ?></span>
				</div>
			</div>
		</div>
	</footer>

</div> <!-- #page -->

<?php wp_footer(); ?>
</body>
</html>